-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2025 at 07:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `workshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin'),
(2, 'mb@gmail.com', 'mb'),
(3, 'bisht@gmail.com', 'bisht');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `movie` varchar(225) NOT NULL,
  `category` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `movie`, `category`, `image`) VALUES
(117, 'HIT', 'TV Shows', 'e.jpg'),
(120, 'Jumanji ', 'Movies', 'j.jpg'),
(123, 'Deewaniyat', 'TV Shows', 'f.jpg'),
(124, 'Baaghi 4 ', 'TV Shows', 'g.jpg'),
(125, 'Pushpa 2 ', 'TV Shows', 'i.jpg'),
(126, 'Sultan', 'Movies', 'c.jpg'),
(127, 'Dragon ', 'Movies', 'd.jpg'),
(128, 'Param Sundari', 'Movies', 'h.jpg'),
(130, 'Peaky Blinders', 'Trending Movies', 'k.jpg'),
(131, 'Wednesday', 'Trending Movies', 'l.jpg'),
(132, 'Money Heist', 'Trending Movies', 'm.jpg'),
(136, 'John Wick 2', 'Trending Movies', 'n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `id` int(224) NOT NULL,
  `movie` varchar(254) NOT NULL,
  `youtube_url` varchar(245) NOT NULL,
  `title` varchar(254) NOT NULL,
  `description` varchar(265) NOT NULL,
  `director` varchar(233) NOT NULL,
  `cast` varchar(254) NOT NULL,
  `language` varchar(245) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `movie`, `youtube_url`, `title`, `description`, `director`, `cast`, `language`, `date`) VALUES
(25, 'Deewaniyat', 'https://youtu.be/dGb3acfZp2k?si=hk-PqHXuJgUzaGEE', 'Ek Deewane ki Deewaniyat ', 'The story focuses on the lives of Jeet and Mannat caught in a blossoming love story amidst an intense feud between their families. Will their love win over the hatred of their families .', ' Milap Zaveri', 'Sonam Bajwa  Harshvardhan Rane', ' Hindi', '2025-10-09'),
(26, 'Baaghi 4 ', 'https://youtu.be/W7OQaRnopRE?list=RDW7OQaRnopRE', 'Baaghi 4', 'A man survives a suicide attempt, but his reality blurs. His loved ones question him as a hidden truth draws him into a web of obsession and enduring love.', 'A.Harsha ', 'Tiger, Sanjay, Harnaaz, Sonam | Sajid Nadiadwala', 'Hindi', '2025-09-26'),
(27, 'Pushpa 2 ', 'https://youtu.be/1kVK0MZlbI4?si=-ApPyBHN_5N29oew', 'Pushpa 2 - The Rule', 'A powerful smuggler goes head-to-head with a vengeful enemy while controlling politics and managing high-stakes confrontations. A public apology sparks a tense showdown, culminating in a challenge.', 'Sukumar', 'Allu Arjun, Rashmika Mandanna, Fahadh Faasil', 'Hindi', '2025-09-13'),
(28, 'Sultan', 'https://youtu.be/wPxqcq6Byq0', 'Sultan', 'After the death of his son, Sultan Ali Khan, a middle-aged wrestler, gives up the sport. Years later, he sets out to revive his career as he needs the prize money and wants to regain his lost respect.', 'Ali Abbas Zafar', 'Salman Khan (Sultan Ali Khan) ,Anushka Sharma (Aarfa) Randeep Hooda (Sultan\'s coach)  Amit Sadh (Aakash) ', ' Hindi', '2024-06-12'),
(29, 'Dragon ', 'https://youtu.be/_QtQtGAB5II', 'Dragon ', ' DRAGON! This highly anticipated film features a stellar cast including the powerhouse JR. NTR, the versatile Bobby Deol, the talented Jahnvi Kapoor, and is directed by the acclaimed Prashanth Neel. Prepare yourself for an action-packed journey with groundbreaking ', ' Prashanth Neel', 'Jr. NTR , Rukmini Vasanth ,Prakash Raj, Prabhas Srinu', ' hindi', '2025-10-09'),
(30, 'Peaky Blinders', 'https://youtu.be/vcDjSZegQjc', 'Peaky Blinders', 'Tommy Shelby, a dangerous man, leads the Peaky Blinders, a gang based in Birmingham. Soon, Chester Campbell, an inspector, decides to nab him and put an end to the criminal activities.', ' Colm McCarthy', ' Cillian Murphy ,Tommy Shelby , Paul Anderson ', 'English ,hindi', '2025-09-15'),
(31, 'Wednesday', 'https://youtu.be/Di310WS8zLk', 'Wednesday', 'While attending Nevermore Academy, Wednesday Addams attempts to master her emerging psychic ability, thwart a killing spree and solve the mystery that embroiled her parents 25 years ago.', 'Tim Burton', 'Jenna Ortega Wednesday Addams  , Emma Myers Enid Sinclair , Hunter Doohan Tyler Galpin', 'English ,Hindi', '2025-09-22'),
(32, 'Money Heist', 'https://youtu.be/ZAXA1DV4dtI', 'Money Heist', 'When the national mint and a touring school group are held hostage by robbers, police believe that the thieves have no way out. Little do they know that the thieves have a bigger plan in store.', 'Álex Pina', ' Álvaro Morte The Professor , Úrsula Corberó Tokyo  , Pedro Alonso Berlin ,  Itziar Ituño', 'Hindi , English', '2025-08-31'),
(35, 'Jumanji ', 'https://youtu.be/2QKg5SZ_35I', 'Jumanji: Welcome to the Jungl‪e', 'When four students play with a magical video game, they are drawn to the jungle world of Jumanji, where they are trapped as their avatars. To return to the real world, they must finish the game.', 'Jake Kasdan', 'Johnson ,Dr. Smolder Bravestone . Jack Black ,Professor Shelly Oberon , Kevin Hart', ' Hindi , English', '2025-10-04'),
(36, 'HIT', 'https://youtu.be/VOScrKrY2fM', 'HIT : The First Case', 'A police officer in the homicide intervention team must overcome his struggles with his tragic past in order to investigate a case involving a missing woman.', ' Sailesh Kolanu', 'Adivi Sesh ,Vishwak Sen (Vikram) ', 'Hindi ', '2025-10-07'),
(38, 'Param Sundari', 'https://youtu.be/fdWnfzsx-ks?list=RDfdWnfzsx-ks', 'Param Sundari', 'Two hearts collide as a North and South Indian unexpectedly fall for each other. Their diverse backgrounds ignite a comedic and tumultuous love story, brimming with cultural misadventures.', 'Tushar Jalota', 'Janhvi Kapoor Sundari , Sidharth Malhotra Param', 'Hindi', '2025-10-09'),
(39, 'John Wick 2', 'https://youtu.be/ChpLV9AMqm4', 'John Wick: Chapter 2', 'John Wick, a retired hitman, visits Italy to pay off an inescapable blood debt. However, he soon finds himself cornered by every killer in the business due to an enormous bounty on his head.', 'Chad Stahelski', 'Keanu Reeves John Wick  , Ruby Rose Ares', 'English ,Hindi', '2025-10-04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(224) NOT NULL,
  `username` varchar(254) NOT NULL,
  `email` varchar(245) NOT NULL,
  `password` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'mohit', 'mb@gmail.com', '12345'),
(2, 'bisht', 'bisht@gmail.com', '$2y$10$uP/X4S9/KLpqLd9bEuf.zOxNrKAUa28fQXOxF.2KROZSaPJhaQ5F.'),
(5, 'mohit', 'mohit@gmail.com', '$2y$10$ePdYCjGkFxhO3ej7NwNBqeZO6embF1CQMBJgytM6uGWJYzaQQrZDS'),
(6, 'hbis', 'hbis@gmail.com', '$2y$10$81UJxjG0RXFcwwJ6juImP.1sQcY3dQDXtDGZ/ybJV.t0kono02nAu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(224) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(224) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
